
public class Main {

	public static void main(String[] args) {
		
		MyMain run = new MyMain();
		
		run.setup();

	}

}
